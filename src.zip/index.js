const app=require("./app.js");
const PORT=8000;
app.listen(PORT,function () {
    console.log("App Run @8000")
})

